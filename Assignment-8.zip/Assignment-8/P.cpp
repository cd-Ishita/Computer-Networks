#include<iostream>
using namespace std;
int main(){
    int a, b;
    cin>>a>>b;
    cout<<"Sum: "<<a+b<<endl;

    cin>>a>>b;
    cout<<"Difference: "<<a-b<<endl;

    cin>>a>>b;
    cout<<"Product: "<<a*b<<endl;
    return 0;
}